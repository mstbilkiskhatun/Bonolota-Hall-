
package bonolota.hall;

import java.awt.*;
import java.awt.event.*;
import java.util.Random;
import javax.swing.*;

class StaffAdd implements ActionListener{

    JFrame f;
    JLabel id,id1,id2,id3,id4,id5,id6,id7,id8,id9,id10,id11,id12,id15,id16,id17,id18,lab,lab1,lab2;
    JTextField t,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14;
    JButton b,b1,b2,b3;
    JComboBox c1,c2;
    
      
    /*Random ran = new Random();
    long first4 = (ran.nextLong() % 9000L) + 1000L;
    long first = Math.abs(first4);
    */
    

    public StaffAdd(){
        f = new JFrame("Add Staff");
        f.setBackground(Color.white);
        f.setLayout(null);

        id15=new JLabel();
        id15.setBounds(0,0,900,700);
        id15.setLayout(null);
        ImageIcon img = new ImageIcon(ClassLoader.getSystemResource("bonolota\\hall\\icon/5.png"));
        Image i3 = img.getImage().getScaledInstance(1220, 700,Image.SCALE_DEFAULT);
        ImageIcon icc3 = new ImageIcon(i3);
        id15.setIcon(icc3);

        id8 = new JLabel("New Staff Details");
        id8.setBounds(320,70,500,50);
        id8.setFont(new Font("serif",Font.BOLD,25));
        id8.setForeground(Color.black);
        id15.add(id8);
        f.add(id15);

 
        id1 = new JLabel("Name");
        id1.setBounds(70,250,150,30);
        id1.setFont(new Font("serif",Font.BOLD,20));
        id15.add(id1);

        t1=new JTextField();
        t1.setBounds(200,250,150,30);
        id15.add(t1);

       
        
        id2= new JLabel("Staff ID");
        id2.setBounds(70,300,150,30);
        id2.setFont(new Font("serif",Font.BOLD,17));
        id15.add(id2);

        t2=new JTextField();   
        t2.setBounds(200,300,150,30);
        id15.add(t2);

        id3= new JLabel("Age");
        id3.setBounds(70,350,150,30);
        id3.setFont(new Font("serif",Font.BOLD,20));
        id15.add(id3);

        t3=new JTextField();
        t3.setBounds(200,350,150,30);
        id15.add(t3);
        
        

        id4= new JLabel("Date of Birth");  
        id4.setBounds(70,400,150,30);
        id4.setFont(new Font("serif",Font.BOLD,20));
        id15.add(id4);

        t4=new JTextField();
        t4.setBounds(200,400,150,30);
        id15.add(t4);

        
        
        

        id6= new JLabel("Phone");
        id6.setBounds(400,250,150,30);
        id6.setFont(new Font("serif",Font.BOLD,20));
        id15.add(id6);

        t6=new JTextField();
        t6.setBounds(530,250,150,30);
        id15.add(t6);


        
        lab2=new JLabel("DEPARTMENT");
        lab2.setBounds(400,300,150,30);
	lab2.setFont(new Font("serif",Font.BOLD,17));
        id15.add(lab2);
        
        String branch[] = {"Security Guard","Assistant Security Guard","Supervisor","Asistant Supervisor","Acountant","Head Cheif","Asistant Cheif","Mess Waiter"};
        c2 = new JComboBox(branch);
        c2.setBackground(Color.WHITE);
        c2.setBounds(530,300,150,30);
        id15.add(c2);

        id7= new JLabel("NID");
        id7.setBounds(400,350,150,30);
        id7.setFont(new Font("serif",Font.BOLD,20));    
        id15.add(id7);

        t8=new JTextField();
        t8.setBounds(530,350,150,30);
        id15.add(t8);
        
        id5= new JLabel("Address");
        id5.setBounds(400,400,150,30);
        id5.setFont(new Font("serif",Font.BOLD,20));
        id15.add(id5);

        t5=new JTextField();
        t5.setBounds(530,400,150,30);
        id15.add(t5);
                
        b = new JButton("Submit");
        b.setBackground(Color.BLACK);
        b.setForeground(Color.WHITE);
        b.setBounds(250,550,150,40);
        
        id15.add(b);

        b1=new JButton("Cancel");   
        b1.setBackground(Color.BLACK);
        b1.setForeground(Color.WHITE);
        b1.setBounds(450,550,150,40);
        
        id15.add(b1);
        
        b.addActionListener(this);
        b1.addActionListener(this);
        
        f.setVisible(true);
        f.setSize(900,700);
        f.setLocation(400,150);
    }

    public void actionPerformed(ActionEvent ae){
        
        String a = t1.getText();
        String bb = t2.getText();
        String c = t3.getText();
        String d = t4.getText();
        String e = t6.getText();
        String ff =(String)c2.getSelectedItem();
        String g = t8.getText();
        String h = t5.getText();
      
        
        
        if(ae.getSource() == b){
            try{
                Connect cc = new Connect();
                String q = "INSERT INTO addstaff VALUES('"+a+"','"+bb+"','"+c+"','"+d+"','"+e+"','"+ff+"','"+g+"','"+h+"')";
                cc.s.executeUpdate(q);
                JOptionPane.showMessageDialog(null,"Staff Details Inserted Successfully");
                f.setVisible(false);
            }
            catch(Exception ee){
                System.out.println("The error is:"+ee);
            }
        }else if(ae.getSource() == b1){
            f.setVisible(false);
           // new Project().setVisible(true);
            
        }
    }
    public static void main(String[ ] arg){
        new StaffAdd().f.setVisible(true);
    }
}


    